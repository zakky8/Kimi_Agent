# AI Trading Agent - Free Data Sources Edition

An institutional-grade AI trading agent that uses exclusively free data sources for real-time market analysis, sentiment tracking, and signal generation.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Python](https://img.shields.io/badge/python-3.9+-green)
![React](https://img.shields.io/badge/react-18+-61DAFB)

## Features

### Data Collection (All Free Sources)
- **Twitter/X API** - Social sentiment analysis (Free tier: 500k tweets/month)
- **Reddit API** - Community sentiment tracking (Free: 60 req/min)
- **Yahoo Finance** - Stock & crypto price data (Free, no API key)
- **CryptoCompare** - Crypto market data (Free: 100k calls/month)
- **Alpha Vantage** - Forex & stock data (Free: 25 calls/day)
- **Finnhub** - Financial data (Free: 60 calls/min)
- **Web Scraping** - Economic calendars, fear & greed indices
- **RSS Feeds** - Financial news aggregation

### Technical Analysis
- 20+ Technical Indicators (RSI, MACD, Bollinger Bands, ADX, etc.)
- Pattern Recognition (Head & Shoulders, Double Tops/Bottoms, Triangles)
- Market Regime Detection (Trending, Range-bound, Volatile)
- Support/Resistance Level Detection
- Multi-timeframe Analysis

### Signal Generation
- Confluence-based signal filtering (3+ confirming factors required)
- Risk-adjusted position sizing
- ATR-based stop loss and take profit calculations
- Risk:Reward optimization (1:2 to 1:4)
- Signal strength classification (Strong/Moderate/Weak)

### Real-time Dashboard
- Live price charts with Lightweight Charts
- WebSocket streaming for real-time updates
- Sentiment gauges and social media feeds
- Active signals monitoring
- News aggregation

## Project Structure

```
trading-agent/
├── backend/                 # Python FastAPI backend
│   ├── app/
│   │   ├── data_collection/ # Data source connectors
│   │   ├── analysis/        # Technical analysis engine
│   │   ├── signals/         # Signal generation
│   │   ├── api/             # REST API routes
│   │   ├── websocket/       # WebSocket server
│   │   └── config.py        # Configuration
│   ├── main.py              # Entry point
│   ├── requirements.txt     # Python dependencies
│   └── .env.example         # Environment template
├── frontend/                # React TypeScript frontend
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── pages/           # Page components
│   │   ├── hooks/           # Custom React hooks
│   │   └── App.tsx          # Main app
│   ├── package.json         # Node dependencies
│   └── .env.example         # Frontend env template
├── docs/                    # Documentation
├── scripts/                 # Installation scripts
└── README.md               # This file
```

## Quick Start

### Prerequisites
- Python 3.9+
- Node.js 18+
- Git

### Installation

#### Option 1: Automated Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/trading-agent.git
cd trading-agent

# Run the installation script
chmod +x scripts/install.sh
./scripts/install.sh
```

#### Option 2: Manual Installation

**Backend Setup:**
```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Copy environment file
cp .env.example .env

# Edit .env with your API keys (all free tiers)
```

**Frontend Setup:**
```bash
cd frontend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env
```

### Running the Application

**Start the Backend:**
```bash
cd backend
source venv/bin/activate  # On Windows: venv\Scripts\activate
python main.py
```
Backend will start at: http://localhost:8000

**Start the Frontend:**
```bash
cd frontend
npm run dev
```
Frontend will start at: http://localhost:3000

## API Keys Setup (Free Tiers)

### Required APIs (All Free)

1. **Twitter/X API** (Optional - for sentiment)
   - Sign up: https://developer.twitter.com/en/portal/dashboard
   - Free tier: 500k tweets/month
   - Add to `.env`: `TWITTER_BEARER_TOKEN`

2. **Reddit API** (Optional - for sentiment)
   - Create app: https://www.reddit.com/prefs/apps
   - Free tier: 60 requests/minute
   - Add to `.env`: `REDDIT_CLIENT_ID`, `REDDIT_CLIENT_SECRET`

3. **Alpha Vantage** (Optional - for forex)
   - Get key: https://www.alphavantage.co/support/#api-key
   - Free tier: 25 calls/day
   - Add to `.env`: `ALPHA_VANTAGE_API_KEY`

4. **CryptoCompare** (Optional - for crypto)
   - Get key: https://www.cryptocompare.com/cryptopian/api-keys
   - Free tier: 100k calls/month
   - Add to `.env`: `CRYPTOCOMPARE_API_KEY`

5. **Finnhub** (Optional - for stocks)
   - Get key: https://finnhub.io/register
   - Free tier: 60 calls/minute
   - Add to `.env`: `FINNHUB_API_KEY`

6. **NewsAPI** (Optional - for news)
   - Get key: https://newsapi.org/register
   - Free tier: 100 requests/day
   - Add to `.env`: `NEWSAPI_KEY`

**Note:** The system works without any API keys using Yahoo Finance and web scraping as fallback sources.

## Usage

### Dashboard
- View live prices and charts
- Monitor active signals
- Track market sentiment
- Read latest news

### Signals
- Generate signals for any symbol
- Filter by direction (Long/Short)
- View signal confidence and R:R ratio
- Export signals

### Analysis
- Technical indicators for any symbol
- Pattern recognition
- Market regime detection
- Support/Resistance levels

### Sentiment
- Twitter/X sentiment analysis
- Reddit community sentiment
- Fear & Greed indices
- Latest news aggregation

## API Endpoints

### Market Data
- `GET /api/v1/market/price/{symbol}` - Current price
- `GET /api/v1/market/prices?symbols=BTCUSD,ETHUSD` - Multiple prices
- `GET /api/v1/market/historical/{symbol}?timeframe=1h` - OHLCV data

### Sentiment
- `GET /api/v1/sentiment/{symbol}` - Symbol sentiment
- `GET /api/v1/sentiment/market/wide` - Market-wide sentiment

### Analysis
- `GET /api/v1/analysis/{symbol}` - Technical analysis

### Signals
- `GET /api/v1/signals/generate/{symbol}` - Generate signal
- `GET /api/v1/signals/active` - Active signals

### Social
- `GET /api/v1/social/twitter/{symbol}` - Twitter data
- `GET /api/v1/social/reddit/{symbol}` - Reddit data

## WebSocket

Connect to `ws://localhost:8001` for real-time updates:

```javascript
const ws = new WebSocket('ws://localhost:8001');

ws.onopen = () => {
  ws.send(JSON.stringify({ action: 'subscribe', channel: 'all' }));
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log(data);
};
```

Channels: `prices`, `signals`, `sentiment`, `all`

## Configuration

Edit `backend/.env` to customize:

```env
# Risk Management
MAX_DRAWDOWN_PERCENT=10
DAILY_LOSS_LIMIT_PERCENT=2
PER_TRADE_RISK_PERCENT=1

# Signal Settings
MIN_CONFIDENCE_THRESHOLD=0.75
CONFLUENCE_FACTORS_REQUIRED=3

# Trading Pairs
DEFAULT_PAIRS=["EURUSD", "GBPUSD", "BTCUSD", "ETHUSD"]
```

## Deployment

### Local Deployment
```bash
# Backend
cd backend
pip install -r requirements.txt
python main.py

# Frontend (new terminal)
cd frontend
npm install
npm run build
npm run preview
```

### Docker Deployment
```bash
# Build and run with Docker Compose
docker-compose up -d
```

### Cloud Deployment (Free Options)
- **Backend**: Railway, Render, Fly.io
- **Frontend**: Vercel, Netlify, GitHub Pages

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Commit changes: `git commit -am 'Add feature'`
4. Push to branch: `git push origin feature-name`
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Disclaimer

This software is for educational and research purposes only. Not financial advice. Trading carries significant risk of loss. Always do your own research and consider consulting with a financial advisor.

## Support

- GitHub Issues: https://github.com/yourusername/trading-agent/issues
- Documentation: https://docs.trading-agent.com
- Discord: https://discord.gg/trading-agent

## Roadmap

- [ ] Machine Learning model integration
- [ ] Backtesting engine
- [ ] Portfolio tracking
- [ ] More data sources
- [ ] Mobile app
- [ ] Alert notifications
- [ ] Paper trading mode

---

**Built with Python, FastAPI, React, and free data sources.**

"""
Institutional-Grade AI Trading Agent
Free Data Sources Edition
"""

__version__ = "1.0.0"
__author__ = "Trading Agent Team"

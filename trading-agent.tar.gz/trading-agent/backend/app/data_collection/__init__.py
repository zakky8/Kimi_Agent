"""
Data Collection Module
Handles free data sources for trading signals
"""

from .twitter_collector import TwitterCollector
from .reddit_collector import RedditCollector
from .web_scraper import WebScraper
from .news_collector import NewsCollector
from .market_data import MarketDataCollector

__all__ = [
    "TwitterCollector",
    "RedditCollector", 
    "WebScraper",
    "NewsCollector",
    "MarketDataCollector"
]

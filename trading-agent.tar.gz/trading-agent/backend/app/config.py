"""
Configuration settings for the Trading Agent
"""
import os
from pydantic_settings import BaseSettings
from typing import List, Optional


class Settings(BaseSettings):
    """Application settings with environment variable support"""
    
    # App Settings
    APP_NAME: str = "AI Trading Agent"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True
    ENVIRONMENT: str = "development"
    
    # Server Settings
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    WEBSOCKET_PORT: int = 8001
    
    # Database
    DATABASE_URL: str = "sqlite:///./trading_agent.db"
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # API Keys (Free Tiers)
    # Alpha Vantage (Free: 25 calls/day)
    ALPHA_VANTAGE_API_KEY: Optional[str] = None
    
    # CryptoCompare (Free: 100k calls/month)
    CRYPTOCOMPARE_API_KEY: Optional[str] = None
    
    # Twitter/X API (Free Tier available)
    TWITTER_BEARER_TOKEN: Optional[str] = None
    TWITTER_API_KEY: Optional[str] = None
    TWITTER_API_SECRET: Optional[str] = None
    TWITTER_ACCESS_TOKEN: Optional[str] = None
    TWITTER_ACCESS_SECRET: Optional[str] = None
    
    # Reddit API (Free)
    REDDIT_CLIENT_ID: Optional[str] = None
    REDDIT_CLIENT_SECRET: Optional[str] = None
    REDDIT_USER_AGENT: str = "TradingAgent/1.0"
    
    # NewsAPI (Free: 100 requests/day)
    NEWSAPI_KEY: Optional[str] = None
    
    # Finnhub (Free: 60 calls/minute)
    FINNHUB_API_KEY: Optional[str] = None
    
    # Trading Settings
    DEFAULT_PAIRS: List[str] = [
        "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD",
        "BTCUSD", "ETHUSD", "SOLUSD", "BNBUSD",
        "XAUUSD", "XAGUSD", "USOIL", "NATGAS"
    ]
    
    # Risk Management
    MAX_DRAWDOWN_PERCENT: float = 10.0
    DAILY_LOSS_LIMIT_PERCENT: float = 2.0
    PER_TRADE_RISK_PERCENT: float = 1.0
    DEFAULT_RISK_REWARD: float = 2.0
    
    # Signal Generation
    MIN_CONFIDENCE_THRESHOLD: float = 0.75
    CONFLUENCE_FACTORS_REQUIRED: int = 3
    
    # Data Collection
    SOCIAL_MEDIA_SCAN_INTERVAL: int = 300  # 5 minutes
    NEWS_SCAN_INTERVAL: int = 600  # 10 minutes
    CHART_UPDATE_INTERVAL: int = 60  # 1 minute
    
    # Technical Analysis
    TIMEFRAMES: List[str] = ["1m", "5m", "15m", "1h", "4h", "1d"]
    DEFAULT_TIMEFRAME: str = "1h"
    
    # Web Scraping
    USER_AGENT: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    REQUEST_TIMEOUT: int = 30
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "./logs/trading_agent.log"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()


# Trading Pairs Configuration
TRADING_PAIRS_CONFIG = {
    "EURUSD": {
        "type": "forex",
        "pip_value": 0.0001,
        "spread_avg": 0.0001,
        "volatility": "medium",
        "trading_hours": "24/5"
    },
    "GBPUSD": {
        "type": "forex",
        "pip_value": 0.0001,
        "spread_avg": 0.0002,
        "volatility": "high",
        "trading_hours": "24/5"
    },
    "USDJPY": {
        "type": "forex",
        "pip_value": 0.01,
        "spread_avg": 0.01,
        "volatility": "medium",
        "trading_hours": "24/5"
    },
    "BTCUSD": {
        "type": "crypto",
        "pip_value": 1.0,
        "spread_avg": 10.0,
        "volatility": "very_high",
        "trading_hours": "24/7"
    },
    "ETHUSD": {
        "type": "crypto",
        "pip_value": 0.01,
        "spread_avg": 0.5,
        "volatility": "very_high",
        "trading_hours": "24/7"
    },
    "XAUUSD": {
        "type": "commodity",
        "pip_value": 0.01,
        "spread_avg": 0.1,
        "volatility": "medium",
        "trading_hours": "23/5"
    },
    "USOIL": {
        "type": "commodity",
        "pip_value": 0.01,
        "spread_avg": 0.03,
        "volatility": "high",
        "trading_hours": "23/5"
    }
}


# Free Data Sources Configuration
FREE_DATA_SOURCES = {
    "yahoo_finance": {
        "enabled": True,
        "rate_limit": "2000/hour",
        "description": "Free stock and crypto data"
    },
    "alpha_vantage": {
        "enabled": True,
        "rate_limit": "25/day",
        "description": "Free forex and stock data"
    },
    "cryptocompare": {
        "enabled": True,
        "rate_limit": "100k/month",
        "description": "Free crypto data"
    },
    "finnhub": {
        "enabled": True,
        "rate_limit": "60/min",
        "description": "Free financial data"
    },
    "twitter": {
        "enabled": True,
        "rate_limit": "500k/month (free tier)",
        "description": "Social sentiment"
    },
    "reddit": {
        "enabled": True,
        "rate_limit": "60/min",
        "description": "Community sentiment"
    },
    "newsapi": {
        "enabled": True,
        "rate_limit": "100/day",
        "description": "News headlines"
    },
    "web_scraping": {
        "enabled": True,
        "rate_limit": "respect robots.txt",
        "description": "Alternative data sources"
    }
}

"""
API Module
FastAPI routes for the trading agent
"""

from .routes import router

__all__ = ["router"]

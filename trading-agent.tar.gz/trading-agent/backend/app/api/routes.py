"""
API Routes
FastAPI endpoints for the trading agent
"""
from fastapi import APIRouter, HTTPException, Query, BackgroundTasks
from fastapi.responses import JSONResponse
from typing import List, Optional, Dict, Any
from pydantic import BaseModel
from datetime import datetime
import asyncio
import logging

from ..data_collection import (
    get_twitter_collector,
    get_reddit_collector,
    get_web_scraper,
    get_news_collector,
    get_market_collector
)
from ..signals import get_signal_generator, get_sentiment_analyzer
from ..config import settings, TRADING_PAIRS_CONFIG

logger = logging.getLogger(__name__)

router = APIRouter()


# ==================== Pydantic Models ====================

class SignalResponse(BaseModel):
    symbol: str
    direction: str
    strength: str
    confidence: float
    entry_price: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]
    risk_reward: Optional[float]
    strategy: str
    reasons: List[str]
    timestamp: str


class SentimentResponse(BaseModel):
    symbol: str
    overall_score: float
    label: str
    source_breakdown: List[Dict[str, Any]]
    timestamp: str


class MarketDataResponse(BaseModel):
    symbol: str
    price: Optional[float]
    change_24h: Optional[float]
    change_percent_24h: Optional[float]
    high_24h: Optional[float]
    low_24h: Optional[float]
    volume_24h: Optional[float]
    timestamp: str


class AnalysisResponse(BaseModel):
    symbol: str
    indicators: Dict[str, Any]
    patterns: Dict[str, Any]
    regime: Dict[str, Any]
    support_resistance: Dict[str, List[float]]
    timestamp: str


# ==================== Health & Status ====================

@router.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "timestamp": datetime.now().isoformat()
    }


@router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat()
    }


@router.get("/config")
async def get_config():
    """Get trading agent configuration"""
    return {
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "default_pairs": settings.DEFAULT_PAIRS,
        "timeframes": settings.TIMEFRAMES,
        "risk_settings": {
            "max_drawdown": settings.MAX_DRAWDOWN_PERCENT,
            "daily_loss_limit": settings.DAILY_LOSS_LIMIT_PERCENT,
            "per_trade_risk": settings.PER_TRADE_RISK_PERCENT
        },
        "data_sources": {
            k: v for k, v in {
                "twitter": bool(settings.TWITTER_BEARER_TOKEN),
                "reddit": bool(settings.REDDIT_CLIENT_ID),
                "alpha_vantage": bool(settings.ALPHA_VANTAGE_API_KEY),
                "cryptocompare": bool(settings.CRYPTOCOMPARE_API_KEY),
                "finnhub": bool(settings.FINNHUB_API_KEY),
                "newsapi": bool(settings.NEWSAPI_KEY)
            }.items()
        }
    }


# ==================== Market Data ====================

@router.get("/market/price/{symbol}", response_model=MarketDataResponse)
async def get_price(symbol: str):
    """Get current price for a symbol"""
    try:
        from ..data_collection.market_data import MarketDataCollector
        
        async with MarketDataCollector() as collector:
            data = await collector.get_ticker_24h(symbol.upper())
            
            return MarketDataResponse(
                symbol=symbol.upper(),
                price=data.get("price"),
                change_24h=data.get("change_24h"),
                change_percent_24h=data.get("change_percent_24h"),
                high_24h=data.get("high_24h"),
                low_24h=data.get("low_24h"),
                volume_24h=data.get("volume_24h"),
                timestamp=datetime.now().isoformat()
            )
    except Exception as e:
        logger.error(f"Error getting price for {symbol}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/market/prices")
async def get_multiple_prices(symbols: str = Query(..., description="Comma-separated symbols")):
    """Get prices for multiple symbols"""
    try:
        symbol_list = [s.strip().upper() for s in symbols.split(",")]
        
        from ..data_collection.market_data import MarketDataCollector
        
        async with MarketDataCollector() as collector:
            data = await collector.get_multiple_prices(symbol_list)
            return data
    except Exception as e:
        logger.error(f"Error getting prices: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/market/historical/{symbol}")
async def get_historical_data(
    symbol: str,
    timeframe: str = Query("1h", description="Timeframe: 1m, 5m, 15m, 1h, 4h, 1d"),
    limit: int = Query(100, description="Number of candles", ge=1, le=1000)
):
    """Get historical OHLCV data"""
    try:
        from ..data_collection.market_data import MarketDataCollector
        
        async with MarketDataCollector() as collector:
            df = await collector.get_historical_data(
                symbol.upper(),
                timeframe=timeframe,
                limit=limit
            )
            
            if df.empty:
                raise HTTPException(status_code=404, detail="No data available")
            
            # Convert to records
            records = df.reset_index().to_dict('records')
            
            # Format timestamps
            for record in records:
                if 'timestamp' in record and hasattr(record['timestamp'], 'isoformat'):
                    record['timestamp'] = record['timestamp'].isoformat()
            
            return {
                "symbol": symbol.upper(),
                "timeframe": timeframe,
                "data": records
            }
    except Exception as e:
        logger.error(f"Error getting historical data: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Sentiment ====================

@router.get("/sentiment/{symbol}", response_model=SentimentResponse)
async def get_sentiment(symbol: str):
    """Get sentiment analysis for a symbol"""
    try:
        from ..data_collection import TwitterCollector, RedditCollector
        from ..signals import SentimentAnalyzer
        
        twitter = None
        reddit = None
        
        if settings.TWITTER_BEARER_TOKEN:
            twitter = TwitterCollector(settings.TWITTER_BEARER_TOKEN)
        
        if settings.REDDIT_CLIENT_ID and settings.REDDIT_CLIENT_SECRET:
            reddit = RedditCollector(
                settings.REDDIT_CLIENT_ID,
                settings.REDDIT_CLIENT_SECRET
            )
        
        analyzer = SentimentAnalyzer(twitter, reddit)
        
        async with twitter or asyncio.NullContext():
            async with reddit or asyncio.NullContext():
                result = await analyzer.analyze_symbol(symbol.upper())
                return result
    except Exception as e:
        logger.error(f"Error getting sentiment: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sentiment/market/wide")
async def get_market_wide_sentiment():
    """Get market-wide sentiment"""
    try:
        from ..data_collection import TwitterCollector, RedditCollector
        from ..signals import SentimentAnalyzer
        
        twitter = None
        reddit = None
        
        if settings.TWITTER_BEARER_TOKEN:
            twitter = TwitterCollector(settings.TWITTER_BEARER_TOKEN)
        
        if settings.REDDIT_CLIENT_ID and settings.REDDIT_CLIENT_SECRET:
            reddit = RedditCollector(
                settings.REDDIT_CLIENT_ID,
                settings.REDDIT_CLIENT_SECRET
            )
        
        analyzer = SentimentAnalyzer(twitter, reddit)
        
        async with twitter or asyncio.NullContext():
            async with reddit or asyncio.NullContext():
                result = await analyzer.get_market_sentiment()
                return result
    except Exception as e:
        logger.error(f"Error getting market sentiment: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Technical Analysis ====================

@router.get("/analysis/{symbol}", response_model=AnalysisResponse)
async def get_technical_analysis(
    symbol: str,
    timeframe: str = Query("1h", description="Timeframe")
):
    """Get technical analysis for a symbol"""
    try:
        from ..data_collection.market_data import MarketDataCollector
        from ..analysis.technical_indicators import TechnicalIndicators
        from ..analysis.pattern_recognition import PatternRecognition
        from ..analysis.market_regime import MarketRegimeDetector
        
        async with MarketDataCollector() as collector:
            df = await collector.get_historical_data(
                symbol.upper(),
                timeframe=timeframe,
                limit=200
            )
            
            if df.empty:
                raise HTTPException(status_code=404, detail="No data available")
            
            # Technical Indicators
            indicators = TechnicalIndicators(df)
            indicators.add_all_indicators()
            indicators.generate_signals()
            
            # Pattern Recognition
            patterns = PatternRecognition(df)
            patterns.detect_all_patterns()
            
            # Market Regime
            regime_detector = MarketRegimeDetector(df)
            regime = regime_detector.detect_regime()
            
            # Support/Resistance
            sr_levels = indicators.get_support_resistance()
            
            return AnalysisResponse(
                symbol=symbol.upper(),
                indicators=indicators.get_summary(),
                patterns=patterns.get_pattern_summary(),
                regime={
                    "current": regime.regime.value,
                    "confidence": regime.confidence,
                    "duration": regime.duration
                },
                support_resistance=sr_levels,
                timestamp=datetime.now().isoformat()
            )
    except Exception as e:
        logger.error(f"Error getting analysis: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Trading Signals ====================

@router.get("/signals/generate/{symbol}", response_model=SignalResponse)
async def generate_signal(
    symbol: str,
    timeframe: str = Query("1h", description="Timeframe")
):
    """Generate trading signal for a symbol"""
    try:
        from ..data_collection.market_data import MarketDataCollector
        from ..data_collection import TwitterCollector, RedditCollector
        from ..signals import SignalGenerator, SentimentAnalyzer
        
        async with MarketDataCollector() as collector:
            # Get market data
            df = await collector.get_historical_data(
                symbol.upper(),
                timeframe=timeframe,
                limit=200
            )
            
            if df.empty:
                raise HTTPException(status_code=404, detail="No data available")
            
            # Get sentiment
            sentiment_data = None
            if settings.TWITTER_BEARER_TOKEN:
                twitter = TwitterCollector(settings.TWITTER_BEARER_TOKEN)
                async with twitter:
                    analyzer = SentimentAnalyzer(twitter)
                    sentiment_data = await analyzer.analyze_symbol(symbol.upper())
            
            # Generate signal
            generator = SignalGenerator()
            signal = await generator.generate_signal(
                symbol.upper(),
                df,
                sentiment_data=sentiment_data
            )
            
            if not signal:
                return JSONResponse(
                    status_code=204,
                    content={"message": "No signal generated - insufficient confidence"}
                )
            
            return SignalResponse(
                symbol=signal.symbol,
                direction=signal.direction.value,
                strength=signal.strength.value,
                confidence=signal.confidence,
                entry_price=signal.entry_price,
                stop_loss=signal.stop_loss,
                take_profit=signal.take_profit,
                risk_reward=signal.risk_reward,
                strategy=signal.strategy,
                reasons=signal.reasons,
                timestamp=signal.timestamp.isoformat()
            )
    except Exception as e:
        logger.error(f"Error generating signal: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/signals/active")
async def get_active_signals():
    """Get all active trading signals"""
    try:
        from ..signals import SignalGenerator
        
        generator = SignalGenerator()
        summary = generator.get_signal_summary()
        
        return summary
    except Exception as e:
        logger.error(f"Error getting active signals: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Social Media ====================

@router.get("/social/twitter/{symbol}")
async def get_twitter_data(symbol: str, limit: int = Query(50, ge=1, le=100)):
    """Get Twitter data for a symbol"""
    try:
        if not settings.TWITTER_BEARER_TOKEN:
            raise HTTPException(status_code=503, detail="Twitter API not configured")
        
        from ..data_collection import TwitterCollector
        
        async with TwitterCollector(settings.TWITTER_BEARER_TOKEN) as twitter:
            sentiment = await twitter.get_trading_sentiment(symbol.upper())
            return sentiment
    except Exception as e:
        logger.error(f"Error getting Twitter data: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/social/reddit/{symbol}")
async def get_reddit_data(symbol: str, limit: int = Query(50, ge=1, le=100)):
    """Get Reddit data for a symbol"""
    try:
        if not settings.REDDIT_CLIENT_ID or not settings.REDDIT_CLIENT_SECRET:
            raise HTTPException(status_code=503, detail="Reddit API not configured")
        
        from ..data_collection import RedditCollector
        
        async with RedditCollector(
            settings.REDDIT_CLIENT_ID,
            settings.REDDIT_CLIENT_SECRET
        ) as reddit:
            sentiment = await reddit.get_symbol_sentiment(symbol.upper())
            return sentiment
    except Exception as e:
        logger.error(f"Error getting Reddit data: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== News ====================

@router.get("/news/market")
async def get_market_news():
    """Get latest market news"""
    try:
        from ..data_collection import WebScraper
        
        async with WebScraper() as scraper:
            summary = await scraper.get_market_summary()
            return summary
    except Exception as e:
        logger.error(f"Error getting news: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Pairs & Markets ====================

@router.get("/pairs")
async def get_trading_pairs():
    """Get available trading pairs"""
    return {
        "pairs": [
            {
                "symbol": symbol,
                **config
            }
            for symbol, config in TRADING_PAIRS_CONFIG.items()
        ]
    }


@router.get("/pairs/{symbol}")
async def get_pair_info(symbol: str):
    """Get info for a specific pair"""
    symbol_upper = symbol.upper()
    
    if symbol_upper not in TRADING_PAIRS_CONFIG:
        raise HTTPException(status_code=404, detail="Pair not found")
    
    return {
        "symbol": symbol_upper,
        **TRADING_PAIRS_CONFIG[symbol_upper]
    }


# ==================== Background Tasks ====================

@router.post("/tasks/scan-all")
async def scan_all_pairs(background_tasks: BackgroundTasks):
    """Start background scan of all pairs"""
    # This would trigger a background task
    return {
        "message": "Scan started",
        "pairs": settings.DEFAULT_PAIRS,
        "timestamp": datetime.now().isoformat()
    }

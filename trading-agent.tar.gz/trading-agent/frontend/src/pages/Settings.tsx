import { useState } from 'react'
import { 
  Settings2, 
  Bell, 
  Shield, 
  Database, 
  Key, 
  Save,
  Check,
  AlertTriangle
} from 'lucide-react'
import { useConfig } from '../hooks/useApi'

export function Settings() {
  const { data: config, isLoading } = useConfig()
  const [saved, setSaved] = useState(false)
  
  const [settings, setSettings] = useState({
    notifications: true,
    emailAlerts: false,
    riskPerTrade: 1,
    maxDrawdown: 10,
    dailyLossLimit: 2,
    defaultTimeframe: '1h',
    minConfidence: 75,
    confluenceFactors: 3,
  })

  const handleSave = () => {
    // In a real app, this would save to the backend
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Configure your trading agent preferences</p>
      </div>

      {/* API Status */}
      <div className="glass rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Key className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">API Connections</h3>
        </div>
        
        {isLoading ? (
          <div className="animate-pulse space-y-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-10 bg-accent rounded" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(config?.data_sources || {}).map(([source, connected]: [string, any]) => (
              <div key={source} className="flex items-center justify-between p-3 bg-accent/50 rounded-lg">
                <span className="capitalize">{source.replace('_', ' ')}</span>
                <span className={`flex items-center gap-1 text-sm ${connected ? 'text-bull' : 'text-bear'}`}>
                  {connected ? (
                    <>
                      <Check className="w-4 h-4" /> Connected
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-4 h-4" /> Not Configured
                    </>
                  )}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risk Management */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Risk Management</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm text-muted-foreground mb-2">
                Risk Per Trade: {settings.riskPerTrade}%
              </label>
              <input
                type="range"
                min="0.5"
                max="5"
                step="0.5"
                value={settings.riskPerTrade}
                onChange={(e) => setSettings({ ...settings, riskPerTrade: parseFloat(e.target.value) })}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm text-muted-foreground mb-2">
                Max Drawdown: {settings.maxDrawdown}%
              </label>
              <input
                type="range"
                min="5"
                max="20"
                step="1"
                value={settings.maxDrawdown}
                onChange={(e) => setSettings({ ...settings, maxDrawdown: parseFloat(e.target.value) })}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm text-muted-foreground mb-2">
                Daily Loss Limit: {settings.dailyLossLimit}%
              </label>
              <input
                type="range"
                min="1"
                max="5"
                step="0.5"
                value={settings.dailyLossLimit}
                onChange={(e) => setSettings({ ...settings, dailyLossLimit: parseFloat(e.target.value) })}
                className="w-full"
              />
            </div>
          </div>
        </div>

        {/* Signal Settings */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Settings2 className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Signal Settings</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm text-muted-foreground mb-2">Default Timeframe</label>
              <select
                value={settings.defaultTimeframe}
                onChange={(e) => setSettings({ ...settings, defaultTimeframe: e.target.value })}
                className="w-full px-4 py-2 bg-accent rounded-lg border border-border outline-none focus:border-primary"
              >
                <option value="1m">1 Minute</option>
                <option value="5m">5 Minutes</option>
                <option value="15m">15 Minutes</option>
                <option value="1h">1 Hour</option>
                <option value="4h">4 Hours</option>
                <option value="1d">1 Day</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-muted-foreground mb-2">
                Minimum Confidence: {settings.minConfidence}%
              </label>
              <input
                type="range"
                min="50"
                max="95"
                step="5"
                value={settings.minConfidence}
                onChange={(e) => setSettings({ ...settings, minConfidence: parseFloat(e.target.value) })}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm text-muted-foreground mb-2">
                Confluence Factors Required: {settings.confluenceFactors}
              </label>
              <input
                type="range"
                min="2"
                max="5"
                step="1"
                value={settings.confluenceFactors}
                onChange={(e) => setSettings({ ...settings, confluenceFactors: parseFloat(e.target.value) })}
                className="w-full"
              />
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Bell className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Notifications</h3>
          </div>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 bg-accent/50 rounded-lg cursor-pointer">
              <span>Push Notifications</span>
              <input
                type="checkbox"
                checked={settings.notifications}
                onChange={(e) => setSettings({ ...settings, notifications: e.target.checked })}
                className="w-5 h-5 rounded border-border"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-accent/50 rounded-lg cursor-pointer">
              <span>Email Alerts</span>
              <input
                type="checkbox"
                checked={settings.emailAlerts}
                onChange={(e) => setSettings({ ...settings, emailAlerts: e.target.checked })}
                className="w-5 h-5 rounded border-border"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-accent/50 rounded-lg cursor-pointer">
              <span>Strong Signals Only</span>
              <input
                type="checkbox"
                defaultChecked
                className="w-5 h-5 rounded border-border"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-accent/50 rounded-lg cursor-pointer">
              <span>Market News Updates</span>
              <input
                type="checkbox"
                defaultChecked
                className="w-5 h-5 rounded border-border"
              />
            </label>
          </div>
        </div>

        {/* Data Sources */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Database className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Data Sources</h3>
          </div>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 bg-accent/50 rounded-lg cursor-pointer">
              <span>Twitter/X Sentiment</span>
              <input
                type="checkbox"
                defaultChecked
                className="w-5 h-5 rounded border-border"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-accent/50 rounded-lg cursor-pointer">
              <span>Reddit Sentiment</span>
              <input
                type="checkbox"
                defaultChecked
                className="w-5 h-5 rounded border-border"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-accent/50 rounded-lg cursor-pointer">
              <span>News Analysis</span>
              <input
                type="checkbox"
                defaultChecked
                className="w-5 h-5 rounded border-border"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-accent/50 rounded-lg cursor-pointer">
              <span>Web Scraping</span>
              <input
                type="checkbox"
                defaultChecked
                className="w-5 h-5 rounded border-border"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors ${
            saved
              ? 'bg-bull text-white'
              : 'bg-primary text-primary-foreground hover:bg-primary/90'
          }`}
        >
          {saved ? (
            <>
              <Check className="w-5 h-5" />
              Saved Successfully
            </>
          ) : (
            <>
              <Save className="w-5 h-5" />
              Save Settings
            </>
          )}
        </button>
      </div>
    </div>
  )
}

import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1'

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
})

// Market Data
export function usePrice(symbol: string) {
  return useQuery({
    queryKey: ['price', symbol],
    queryFn: async () => {
      const { data } = await api.get(`/market/price/${symbol}`)
      return data
    },
    refetchInterval: 5000,
  })
}

export function useMultiplePrices(symbols: string[]) {
  return useQuery({
    queryKey: ['prices', symbols],
    queryFn: async () => {
      const { data } = await api.get(`/market/prices?symbols=${symbols.join(',')}`)
      return data
    },
    refetchInterval: 5000,
  })
}

export function useHistoricalData(symbol: string, timeframe: string = '1h', limit: number = 100) {
  return useQuery({
    queryKey: ['historical', symbol, timeframe, limit],
    queryFn: async () => {
      const { data } = await api.get(`/market/historical/${symbol}?timeframe=${timeframe}&limit=${limit}`)
      return data
    },
  })
}

// Sentiment
export function useSentiment(symbol: string) {
  return useQuery({
    queryKey: ['sentiment', symbol],
    queryFn: async () => {
      const { data } = await api.get(`/sentiment/${symbol}`)
      return data
    },
    refetchInterval: 60000,
  })
}

export function useMarketWideSentiment() {
  return useQuery({
    queryKey: ['sentiment', 'market'],
    queryFn: async () => {
      const { data } = await api.get('/sentiment/market/wide')
      return data
    },
    refetchInterval: 60000,
  })
}

// Analysis
export function useTechnicalAnalysis(symbol: string, timeframe: string = '1h') {
  return useQuery({
    queryKey: ['analysis', symbol, timeframe],
    queryFn: async () => {
      const { data } = await api.get(`/analysis/${symbol}?timeframe=${timeframe}`)
      return data
    },
    refetchInterval: 30000,
  })
}

// Signals
export function useGenerateSignal(symbol: string, timeframe: string = '1h') {
  return useQuery({
    queryKey: ['signal', symbol, timeframe],
    queryFn: async () => {
      const { data } = await api.get(`/signals/generate/${symbol}?timeframe=${timeframe}`)
      return data
    },
    refetchInterval: 60000,
  })
}

export function useActiveSignals() {
  return useQuery({
    queryKey: ['signals', 'active'],
    queryFn: async () => {
      const { data } = await api.get('/signals/active')
      return data
    },
    refetchInterval: 30000,
  })
}

// Social Media
export function useTwitterData(symbol: string) {
  return useQuery({
    queryKey: ['twitter', symbol],
    queryFn: async () => {
      const { data } = await api.get(`/social/twitter/${symbol}`)
      return data
    },
    refetchInterval: 300000, // 5 minutes
  })
}

export function useRedditData(symbol: string) {
  return useQuery({
    queryKey: ['reddit', symbol],
    queryFn: async () => {
      const { data } = await api.get(`/social/reddit/${symbol}`)
      return data
    },
    refetchInterval: 300000,
  })
}

// News
export function useMarketNews() {
  return useQuery({
    queryKey: ['news'],
    queryFn: async () => {
      const { data } = await api.get('/news/market')
      return data
    },
    refetchInterval: 300000,
  })
}

// Config
export function useConfig() {
  return useQuery({
    queryKey: ['config'],
    queryFn: async () => {
      const { data } = await api.get('/config')
      return data
    },
  })
}

// Trading Pairs
export function useTradingPairs() {
  return useQuery({
    queryKey: ['pairs'],
    queryFn: async () => {
      const { data } = await api.get('/pairs')
      return data
    },
  })
}
